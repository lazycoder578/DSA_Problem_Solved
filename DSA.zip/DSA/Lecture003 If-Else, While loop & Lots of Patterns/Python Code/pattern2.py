n = int(input())
i = 1 

while(i < n+1):
    j = 0
    while(j < n):      
        j = j + 1
        print(i, end="")
    i = i + 1
    print('')
