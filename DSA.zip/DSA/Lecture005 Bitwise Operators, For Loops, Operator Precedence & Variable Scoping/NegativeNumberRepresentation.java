public class NegativeNumberRepresentation {
    // Negative Number Representation in Binary
    public static void main(String [] args){
        int a = 10;
        System.out.println( - a + " in Binary: " + Integer.toBinaryString(-a));
    }
}
