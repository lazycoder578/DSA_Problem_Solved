#include<iostream>
using namespace std;

int main() {

    for(int i=0; i<5; i++) {

        cout<< " HI " << endl;
        cout<< " Hey " << endl;
        continue;

        cout<< "Reply toh karde " <<endl;

    }
    return 0;
}