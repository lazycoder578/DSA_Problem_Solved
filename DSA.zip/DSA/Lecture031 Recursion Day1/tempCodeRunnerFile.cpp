 if(n==0)
        return 1;
